package com.example.gddrs_jhonatan;

public class Detrito {
    private String id;
    private String nome;
    private String data;
    private String endereco;
    private String tipoDetrito;
    private String telefone;
    private double latitude;
    private double longitude;

    public Detrito(String id, String nome, String data, String endereco, String tipoDetrito, String telefone, double latitude, double longitude) {
        this.id = id;
        this.nome = nome;
        this.data = data;
        this.endereco = endereco;
        this.tipoDetrito = tipoDetrito;
        this.telefone = telefone;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Getters and setters for all fields
    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getData() {
        return data;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTipoDetrito() {
        return tipoDetrito;
    }

    public String getTelefone() {
        return telefone;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
