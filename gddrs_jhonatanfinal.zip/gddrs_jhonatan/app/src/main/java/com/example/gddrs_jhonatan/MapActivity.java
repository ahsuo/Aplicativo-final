package com.example.gddrs_jhonatan;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.List;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    private MapView mapView;
    private List<Detrito> detritos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        Bundle mapViewBundle = null;
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
        }

        mapView = findViewById(R.id.mapView);
        mapView.onCreate(mapViewBundle);
        mapView.getMapAsync(this);

        // Recuperar a lista de detritos (pode vir de um Intent ou banco de dados)
        detritos = getDetritos(); // Implementar este método para recuperar os detritos
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        for (Detrito detrito : detritos) {
            LatLng location = new LatLng(detrito.getLatitude(), detrito.getLongitude());
            googleMap.addMarker(new MarkerOptions().position(location).title(detrito.getNome()));
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 10));
        }
    }

    private List<Detrito> getDetritos() {
        // Implementar a lógica para recuperar a lista de detritos
        // Pode ser de um banco de dados ou passado via Intent
        // Aqui está um exemplo simulado
        List<Detrito> detritos = new ArrayList<>();
        detritos.add(new Detrito("1", "João Silva", "2023-06-08", "Rua A, 123", "Escombros", "123456789", -23.563987, -46.654321));
        detritos.add(new Detrito("2", "Maria Santos", "2023-06-09", "Rua B, 456", "Vegetação", "987654321", -23.564987, -46.654322));
        return detritos;
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    protected void onPause() {
        mapView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }

        mapView.onSaveInstanceState(mapViewBundle);
    }
}
